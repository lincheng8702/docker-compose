# 

# kafka启动方法

``` sh
cd  kafka
docker-compose up -d
``` 

# rabbitmq启动方法

``` sh
cd  rabbitmq
docker-compose up -d
```



# rabbitmq、mysql、redis启动方法

``` sh
cd  mq-myql-redis
docker-compose up -d
```